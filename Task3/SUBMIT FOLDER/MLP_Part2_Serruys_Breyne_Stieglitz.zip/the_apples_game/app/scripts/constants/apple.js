/*
 * `apple`
 * ======
 *
 */

/**
 * Number of patches where apples appear.
 */
export const N = 5;
